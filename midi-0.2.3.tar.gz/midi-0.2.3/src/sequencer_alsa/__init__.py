try:
    from sequencer import *
except ImportError:
    pass
